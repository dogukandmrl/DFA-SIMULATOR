import java.util.Scanner;

public class Eslesme {
	
	static char guncelKarakter;
	static char guncelDurum;
	static char[] KarakterDizisiSatir;
	static int KarakterDizisiSatirAdet = 0;
	    
	    public static void main(String[] args) {
	        
	        // Scanner objesi
	    	
	        Scanner giris = new Scanner(System.in);
	        
	        // Giri�in al�nmas� 
	        
	        DFA.DFATablosunuAl();
	        
	        boolean kullaniciDurumu = false;
	        
	        while(!kullaniciDurumu){
	        	
	            System.out.println("�stenen giri� String'i girin: ");
	            String stringGiris = giris.nextLine();
	            if(stringGiris.contentEquals("son"))
	                break;
	            else{
	            	
	                // Okunabilir formata �evirilmesi
	            	
	                KarakterDizisiSatir = stringGiris.toCharArray();
	                KarakterDizisiSatirAdet = 0;
	                
	                // Ge�i�lerin ba�lamas�
	                
	                Algoritma();    // String e�le�me algoritmas�
	            }
	        }
	    }
	    
	    private static void Algoritma() {
	           
	    	// DFA Tablosunu bir String ile e�le�tirmek i�in kullan�lan algoritma
	        
	    	guncelDurum = DFA.BaslangicDurumu();     //denotes current state
	        guncelKarakter = SiradakiKarakter();       //current character from the input string
	        while(guncelKarakter != '$'){
	            guncelDurum = Degistir(guncelDurum,guncelKarakter);
	            guncelKarakter = SiradakiKarakter();
	        }
	        // Giri�in do�ru olup olmad���n�n kontrol� 
	        
	        System.out.println(FinalDurumuKontrol());
	    }
	    
	    private static char SiradakiKarakter() {
	        if(KarakterDizisiSatir == null || KarakterDizisiSatirAdet  == KarakterDizisiSatir.length){
	            return '$';
	        }else{
	            return KarakterDizisiSatir[KarakterDizisiSatirAdet++];
	        }
	    }
	    
	    private static char Degistir(char guncelDurum,char guncelKarakter) {
	        return DFA.SiradakiDurum(guncelDurum,guncelKarakter);
	    }

	    private static String FinalDurumuKontrol() {
	            if(DFA.FinalDurumu(guncelDurum)) {
	                return "evet";
	            }else {
	                return "hayir";
	            }
	        }
	}	
	

